// Vercel Serverless Function: api/generate.js
// Proxy seguro para la API Generative Language (Gemini).
// Requiere que la variable de entorno GOOGLE_API_KEY esté configurada en Vercel.

const DEFAULT_MODEL = "gemini-2.5-flash-preview-09-2025";

module.exports = async (req, res) => {
  // Allow preflight and simple CORS (ajusta según tu dominio)
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");

  if (req.method === "OPTIONS") {
    return res.status(200).end();
  }

  if (req.method !== "POST") {
    res.setHeader("Allow", "POST, OPTIONS");
    return res.status(405).json({ error: "Method Not Allowed" });
  }

  try {
    const body = req.body || {};
    const prompt = body.prompt;
    const systemInstruction = body.systemInstruction || "";
    const model = body.model || DEFAULT_MODEL;

    if (!prompt || typeof prompt !== "string") {
      return res.status(400).json({ error: "Missing or invalid 'prompt' in request body." });
    }

    const apiKey = process.env.GOOGLE_API_KEY;
    if (!apiKey) {
      return res.status(500).json({ error: "Server misconfigured: missing GOOGLE_API_KEY." });
    }

    const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;
    const payload = {
      contents: [{ parts: [{ text: prompt }] }],
      systemInstruction: { parts: [{ text: systemInstruction }] },
    };

    // Timeout guard
    const controller = new AbortController();
    const timeoutMs = 15_000;
    const timeout = setTimeout(() => controller.abort(), timeoutMs);

    const r = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
      signal: controller.signal,
    });

    clearTimeout(timeout);

    if (!r.ok) {
      const details = await r.text().catch(() => "");
      return res.status(r.status).json({ error: "Remote API error", details });
    }

    const data = await r.json();
    const text = data?.candidates?.[0]?.content?.parts?.[0]?.text || "";

    // Limitar longitud por seguridad
    const maxLength = 5000;
    const trimmed = text.length > maxLength ? text.slice(0, maxLength) + "…" : text;

    return res.status(200).json({ text: trimmed });
  } catch (err) {
    if (err && err.name === "AbortError") {
      return res.status(504).json({ error: "Request to remote API timed out." });
    }
    console.error("Error in /api/generate:", err);
    return res.status(500).json({ error: "Internal server error." });
  }
};