// server/index.js
// Requiere Node 18+ (fetch disponible globalmente).
import express from "express";
import rateLimit from "express-rate-limit";
import helmet from "helmet";
import cors from "cors";

const app = express();
app.use(helmet());
app.use(express.json({ limit: "20kb" }));
app.use(cors({ origin: true }));

// Rate limit básico
const limiter = rateLimit({
  windowMs: 60 * 1000, // 1 minuto
  max: 60, // límite de 60 peticiones por minuto por IP
});
app.use(limiter);

const DEFAULT_MODEL = "gemini-2.5-flash-preview-09-2025";

app.post("/api/generate", async (req, res) => {
  try {
    const { prompt, systemInstruction = "", model = DEFAULT_MODEL } = req.body || {};
    if (!prompt || typeof prompt !== "string") {
      return res.status(400).json({ error: "Missing or invalid 'prompt' in request body." });
    }

    const apiKey = process.env.GOOGLE_API_KEY;
    if (!apiKey) {
      return res.status(500).json({ error: "Server not configured: missing GOOGLE_API_KEY." });
    }

    const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;
    const payload = {
      contents: [{ parts: [{ text: prompt }] }],
      systemInstruction: { parts: [{ text: systemInstruction }] },
    };

    // Timeout con AbortController
    const controller = new AbortController();
    const timeoutMs = 15_000; // 15s
    const timeout = setTimeout(() => controller.abort(), timeoutMs);

    const response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
      signal: controller.signal,
    });

    clearTimeout(timeout);

    if (!response.ok) {
      const errText = await response.text().catch(() => "");
      return res.status(response.status).json({ error: "Remote API error", details: errText });
    }

    const data = await response.json();
    const text = data?.candidates?.[0]?.content?.parts?.[0]?.text || "";

    // Opcional: limitar la longitud para evitar respuestas inmensas
    const maxLength = 5000;
    const trimmed = text.length > maxLength ? text.slice(0, maxLength) + "…" : text;

    return res.json({ text: trimmed });
  } catch (err) {
    if (err.name === "AbortError") {
      return res.status(504).json({ error: "Request to remote API timed out." });
    }
    console.error("Internal error in /api/generate:", err);
    return res.status(500).json({ error: "Internal server error." });
  }
});

// Health check
app.get("/api/health", (_req, res) => res.json({ ok: true }));

const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`Server listening on port ${port}`);
});