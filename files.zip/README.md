```markdown
# mi-entrenamiento — Vercel API proxy para Gemini

Este cambio añade una ruta serverless para Vercel en `api/generate.js` que actúa como proxy seguro hacia la API Generative Language (Gemini). También se actualiza el cliente para llamar a `/api/generate` en lugar de exponer la API key en el navegador.

Pasos rápidos para desplegar (Vercel)
1. Crea la rama y sube los archivos (comandos abajo).
2. En tu proyecto Vercel, añade la variable de entorno:
   - Key: `GOOGLE_API_KEY`
   - Value: (tu clave real)
   - Añádela para los entornos que uses (Preview y Production).
3. Empuja la rama — Vercel generará un Preview Deploy automáticamente.
4. Abre el PR y revisa el despliegue Preview (en Vercel verás la URL de preview).

Comandos sugeridos (local)
1. Crea la rama:
   - git checkout -b feature/proxy-gemini
2. Añade los archivos (api/generate.js, entrenador_virtual.html, .env.example, README.md)
3. git add .
4. git commit -m "feat: add Vercel proxy /api/generate and update client"
5. git push origin feature/proxy-gemini

Abrir PR (opciones)
- Desde la web: https://github.com/lospensamientos60-lang/mi-entrenamiento/pull/new/feature/proxy-gemini?expand=1
- O usando GitHub CLI:
  - gh pr create --base main --head feature/proxy-gemini --title "feat: add secure proxy for Gemini AI and update client" --body "Añade /api/generate (Vercel) y actualiza cliente para no exponer API key. Recomendaciones: configurar GOOGLE_API_KEY en Vercel y limitar uso."
```